#include "enet/enet.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#endif

static int s_winsockInitialized = 0;

int enet_initialize(void) {
#ifdef _WIN32
    if (s_winsockInitialized) return 0;
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) return -1;
    s_winsockInitialized = 1;
#endif
    return 0;
}

void enet_deinitialize(void) {
#ifdef _WIN32
    if (s_winsockInitialized) {
        WSACleanup();
        s_winsockInitialized = 0;
    }
#endif
}

static int setSocketNonBlocking(int socketfd) {
#ifdef _WIN32
    unsigned long mode = 1;
    return ioctlsocket(socketfd, FIONBIO, &mode);
#else
    int flags = fcntl(socketfd, F_GETFL, 0);
    if (flags == -1) return -1;
    return fcntl(socketfd, F_SETFL, flags | O_NONBLOCK);
#endif
}

static int createSocket(void) {
#ifdef _WIN32
    return (int)socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
#else
    return socket(AF_INET, SOCK_DGRAM, 0);
#endif
}

static void closeSocket(int socketfd) {
#ifdef _WIN32
    closesocket(socketfd);
#else
    close(socketfd);
#endif
}

ENetHost* enet_host_create(const ENetAddress* address, size_t peerCount, size_t channelCount, enet_uint32 incomingBandwidth, enet_uint32 outgoingBandwidth) {
    (void)channelCount;
    (void)incomingBandwidth;
    (void)outgoingBandwidth;

    ENetHost* host = (ENetHost*)malloc(sizeof(ENetHost));
    if (!host) return NULL;
    memset(host, 0, sizeof(ENetHost));

    host->socket = createSocket();
    if (host->socket < 0) {
        free(host);
        return NULL;
    }

    if (address) {
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(address->host);
        addr.sin_port = htons(address->port);
        if (bind(host->socket, (struct sockaddr*)&addr, sizeof(addr)) != 0) {
            closeSocket(host->socket);
            free(host);
            return NULL;
        }
        host->address = *address;
        host->isServer = 1;
    } else {
        host->address.host = 0;
        host->address.port = 0;
        host->isServer = 0;
    }

    host->peers = (ENetPeer*)malloc(sizeof(ENetPeer) * peerCount);
    if (!host->peers) {
        closeSocket(host->socket);
        free(host);
        return NULL;
    }
    memset(host->peers, 0, sizeof(ENetPeer) * peerCount);
    host->peerCount = peerCount;
    host->maxPeers = peerCount;
    setSocketNonBlocking(host->socket);
    return host;
}

void enet_host_destroy(ENetHost* host) {
    if (!host) return;
    if (host->peers) {
        free(host->peers);
    }
    if (host->socket >= 0) {
        closeSocket(host->socket);
    }
    free(host);
}

ENetPeer* enet_host_connect(ENetHost* host, const ENetAddress* address, size_t channelCount, enet_uint32 data) {
    (void)channelCount;
    (void)data;
    if (!host || !address) return NULL;

    ENetPeer* peer = &host->peers[0];
    peer->socket = host->socket;
    peer->address = *address;
    peer->connected = 0;
    peer->data = NULL;

    // send a connect request packet
    enet_uint8 packetData[1] = {0};
    ENetPacket* packet = enet_packet_create(packetData, sizeof(packetData), ENET_PACKET_FLAG_RELIABLE);
    if (!packet) return NULL;
    enet_peer_send(peer, 0, packet);
    enet_host_flush(host);
    return peer;
}

static ENetPeer* findPeerByAddress(ENetHost* host, const ENetAddress* address) {
    if (!host) return NULL;
    for (size_t i = 0; i < host->maxPeers; ++i) {
        ENetPeer* peer = &host->peers[i];
        if (peer->address.host == address->host && peer->address.port == address->port) {
            return peer;
        }
    }
    return NULL;
}

static ENetPeer* allocatePeer(ENetHost* host) {
    if (!host) return NULL;
    for (size_t i = 0; i < host->maxPeers; ++i) {
        ENetPeer* peer = &host->peers[i];
        if (!peer->connected) {
            return peer;
        }
    }
    return NULL;
}

int enet_host_service(ENetHost* host, ENetEvent* event, enet_uint32 timeout) {
    if (!host || !event) return 0;

    fd_set readSet;
    FD_ZERO(&readSet);
    FD_SET((SOCKET)host->socket, &readSet);

    struct timeval tv;
    tv.tv_sec = timeout / 1000;
    tv.tv_usec = (timeout % 1000) * 1000;

    int rc = select((int)host->socket + 1, &readSet, NULL, NULL, &tv);
    if (rc <= 0) {
        event->type = ENET_EVENT_TYPE_NONE;
        event->peer = NULL;
        event->packet = NULL;
        return 0;
    }

    if (FD_ISSET((SOCKET)host->socket, &readSet)) {
        struct sockaddr_in from;
        socklen_t fromLen = sizeof(from);
        enet_uint8 buffer[2048];
        int received = recvfrom(host->socket, (char*)buffer, sizeof(buffer), 0, (struct sockaddr*)&from, &fromLen);
        if (received <= 0) {
            event->type = ENET_EVENT_TYPE_NONE;
            return 0;
        }

        ENetAddress address;
        address.host = ntohl(from.sin_addr.s_addr);
        address.port = ntohs(from.sin_port);

        ENetPeer* peer = findPeerByAddress(host, &address);

        /* SERVER: new peer connecting */
        if (!peer && host->isServer) {
            peer = allocatePeer(host);
            if (peer) {
                peer->socket = host->socket;
                peer->address = address;
                peer->connected = 1;
                peer->data = NULL;
            }
        }

        if (!peer) {
            return 0;
        }

        /* SERVER: client's 1-byte handshake (0x00) — send ack back, fire CONNECT */
        if (received == 1 && buffer[0] == 0x00 && host->isServer) {
            enet_uint8 ack = 0x01;
            struct sockaddr_in ackTo;
            memset(&ackTo, 0, sizeof(ackTo));
            ackTo.sin_family = AF_INET;
            ackTo.sin_addr.s_addr = htonl(peer->address.host);
            ackTo.sin_port = htons(peer->address.port);
            sendto(host->socket, (const char*)&ack, 1, 0, (struct sockaddr*)&ackTo, sizeof(ackTo));

            event->type = ENET_EVENT_TYPE_CONNECT;
            event->peer = peer;
            event->packet = NULL;
            return 1;
        }

        /* CLIENT: first packet from server on unconnected peer.
           Mark connected AND deliver the data — don't discard it.
           This handles both the 0x01 ack and the case where an INIT
           packet arrives before/instead of the ack. */
        if (!peer->connected && !host->isServer) {
            peer->connected = 1;

            /* If it's just the 1-byte handshake ack, fire CONNECT only */
            if (received == 1 && buffer[0] == 0x01) {
                event->type = ENET_EVENT_TYPE_CONNECT;
                event->peer = peer;
                event->packet = NULL;
                return 1;
            }

            /* Otherwise it's a real data packet (e.g. INIT) — fire CONNECT
               but also deliver the packet so it isn't lost. We fire CONNECT
               this time; the packet will be delivered as RECEIVE on the
               next call since we can only return one event per call.
               Actually, we need to deliver the data NOW or it's gone.
               So we fire RECEIVE and let NetworkManager handle the
               implicit connection (it already sets connected=true on
               receiving any packet type). */
            ENetPacket* packet = enet_packet_create(buffer, received, 0);
            if (!packet) {
                event->type = ENET_EVENT_TYPE_CONNECT;
                event->peer = peer;
                event->packet = NULL;
                return 1;
            }
            event->type = ENET_EVENT_TYPE_RECEIVE;
            event->peer = peer;
            event->packet = packet;
            return 1;
        }

        ENetPacket* packet = enet_packet_create(buffer, received, 0);
        if (!packet) {
            event->type = ENET_EVENT_TYPE_NONE;
            return 0;
        }
        event->type = ENET_EVENT_TYPE_RECEIVE;
        event->peer = peer;
        event->packet = packet;
        return 1;
    }

    event->type = ENET_EVENT_TYPE_NONE;
    return 0;
}

ENetPacket* enet_packet_create(const void* data, size_t dataLength, enet_uint32 flags) {
    (void)flags;
    ENetPacket* packet = (ENetPacket*)malloc(sizeof(ENetPacket));
    if (!packet) return NULL;
    packet->data = (enet_uint8*)malloc(dataLength);
    if (!packet->data) {
        free(packet);
        return NULL;
    }
    memcpy(packet->data, data, dataLength);
    packet->dataLength = dataLength;
    return packet;
}

void enet_packet_destroy(ENetPacket* packet) {
    if (!packet) return;
    if (packet->data) free(packet->data);
    free(packet);
}

int enet_peer_send(ENetPeer* peer, enet_uint8 channelID, ENetPacket* packet) {
    (void)channelID;
    if (!peer || !packet) return -1;
    if (peer->socket < 0) return -1;

    struct sockaddr_in to;
    memset(&to, 0, sizeof(to));
    to.sin_family = AF_INET;
    to.sin_addr.s_addr = htonl(peer->address.host);
    to.sin_port = htons(peer->address.port);

    int sent = sendto(peer->socket, (const char*)packet->data, (int)packet->dataLength, 0, (struct sockaddr*)&to, sizeof(to));
    return sent == (int)packet->dataLength ? 0 : -1;
}

void enet_peer_disconnect(ENetPeer* peer, enet_uint32 data) {
    (void)data;
    if (!peer) return;
    peer->connected = 0;
}

void enet_host_flush(ENetHost* host) {
    (void)host;
}

void enet_address_set_host(ENetAddress* address, const char* hostName) {
    if (!address || !hostName) return;
#ifdef _WIN32
    struct addrinfo hints;
    struct addrinfo* result = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    if (getaddrinfo(hostName, NULL, &hints, &result) == 0 && result) {
        struct sockaddr_in* addr = (struct sockaddr_in*)result->ai_addr;
        address->host = ntohl(addr->sin_addr.s_addr);
        freeaddrinfo(result);
    } else {
        address->host = inet_addr(hostName);
    }
#else
    address->host = inet_addr(hostName);
#endif
}
