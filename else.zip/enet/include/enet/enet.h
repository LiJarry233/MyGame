#ifndef ENET_ENET_H
#define ENET_ENET_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t enet_uint8;
typedef uint16_t enet_uint16;
typedef uint32_t enet_uint32;

typedef enum ENetEventType {
    ENET_EVENT_TYPE_NONE = 0,
    ENET_EVENT_TYPE_CONNECT = 1,
    ENET_EVENT_TYPE_RECEIVE = 2,
    ENET_EVENT_TYPE_DISCONNECT = 3
} ENetEventType;

#define ENET_HOST_ANY 0
#define ENET_PACKET_FLAG_RELIABLE 1

typedef struct _ENetAddress {
    enet_uint32 host;
    enet_uint16 port;
} ENetAddress;

typedef struct _ENetPacket {
    size_t dataLength;
    enet_uint8* data;
} ENetPacket;

struct _ENetPeer;

typedef struct _ENetEvent {
    ENetEventType type;
    struct _ENetPeer* peer;
    ENetPacket* packet;
} ENetEvent;

typedef struct _ENetPeer {
    int socket;
    ENetAddress address;
    int connected;
    void* data;
} ENetPeer;

typedef struct _ENetHost {
    int socket;
    ENetAddress address;
    ENetPeer* peers;
    size_t peerCount;
    size_t maxPeers;
    int isServer;
    int connected;
} ENetHost;

int enet_initialize(void);
void enet_deinitialize(void);

ENetHost* enet_host_create(const ENetAddress* address, size_t peerCount, size_t channelCount, enet_uint32 incomingBandwidth, enet_uint32 outgoingBandwidth);
void enet_host_destroy(ENetHost* host);

ENetPeer* enet_host_connect(ENetHost* host, const ENetAddress* address, size_t channelCount, enet_uint32 data);

int enet_host_service(ENetHost* host, ENetEvent* event, enet_uint32 timeout);

ENetPacket* enet_packet_create(const void* data, size_t dataLength, enet_uint32 flags);
void enet_packet_destroy(ENetPacket* packet);

int enet_peer_send(ENetPeer* peer, enet_uint8 channelID, ENetPacket* packet);
void enet_peer_disconnect(ENetPeer* peer, enet_uint32 data);
void enet_host_flush(ENetHost* host);

void enet_address_set_host(ENetAddress* address, const char* hostName);

#ifdef __cplusplus
}
#endif

#endif // ENET_ENET_H
